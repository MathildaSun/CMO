# TipRun Autonomous Marketing System — Technical Specification

Last updated: 2026-01-28

## 1. Technical Context
- Runtime: Node.js 20+, TypeScript
- Package manager: npm or pnpm (assume npm unless specified)
- Frameworks/Libraries:
  - HTTP API: Hono (preferred) or Express
  - AI Orchestration: LangChain.js
  - Queue: BullMQ + ioredis
  - Database: Supabase JS client for Postgres and Storage
  - Vector: pgvector (managed by Supabase)
  - Integrations: Late.dev (HTTP), Fal.ai (HTTP), Apify (HTTP), Resend (official SDK), Slack (@slack/web-api), Telegram (node-telegram-bot-api)
  - Cron: node-cron
  - Logging: minimal structured logger (pino-like shape)
- Testing: Vitest (unit) + lightweight integration mocks for external APIs
- Lint/Typecheck: eslint + typescript (tsc)
- Timezone: Asia/Kolkata (IST); always store/emit ISO8601 in UTC where providers require

## 2. Dependencies
- core: typescript, ts-node, hono, zod, langchain, bullmq, ioredis
- db: @supabase/supabase-js, pg (if direct SQL helpers are needed)
- ai/integrations: resend, @slack/web-api, node-telegram-bot-api, node-cron, cross-fetch (if needed)
- dev: eslint, prettier, vitest, tsx, dotenv, @types/node, @types/express (if Express chosen)

## 3. Source Structure
```
tiprun-marketing-agents/
├── package.json
├── tsconfig.json
├── .env.example
├── src/
│   ├── index.ts
│   ├── api/
│   │   ├── index.ts
│   │   ├── routes/
│   │   │   ├── health.ts
│   │   │   ├── agents.ts
│   │   │   ├── content.ts
│   │   │   └── webhooks.ts
│   │   └── slack/
│   │       └── interactions.ts
│   ├── agents/
│   │   ├── base-agent.ts
│   │   ├── master-cmo.ts
│   │   ├── campaign-manager.ts
│   │   ├── content-manager.ts
│   │   ├── outreach-manager.ts
│   │   ├── research-agent.ts
│   │   ├── operations-agent.ts
│   │   ├── poster-agent.ts
│   │   ├── creatives-agent.ts
│   │   ├── social-listening-agent.ts
│   │   ├── influencer-agent.ts
│   │   ├── email-agent.ts
│   │   ├── pr-agent.ts
│   │   └── community-agent.ts
│   ├── tools/
│   │   ├── late-dev-tools.ts
│   │   ├── fal-ai-tools.ts
│   │   ├── apify-tools.ts
│   │   ├── email-tools.ts
│   │   ├── slack-tools.ts
│   │   ├── database-tools.ts
│   │   └── memory-tools.ts
│   ├── workflows/
│   │   ├── content-publishing.ts
│   │   ├── social-listening.ts
│   │   ├── influencer-outreach.ts
│   │   ├── email-campaigns.ts
│   │   └── research-reports.ts
│   ├── lib/
│   │   ├── database/
│   │   │   ├── index.ts
│   │   │   ├── supabase-client.ts
│   │   │   └── repositories/
│   │   │       ├── content-calendar.ts
│   │   │       ├── campaigns.ts
│   │   │       ├── influencers.ts
│   │   │       ├── email-log.ts
│   │   │       └── memory.ts
│   │   ├── integrations/
│   │   │   ├── late-dev.ts
│   │   │   ├── fal-ai.ts
│   │   │   ├── apify.ts
│   │   │   ├── resend.ts
│   │   │   ├── slack.ts
│   │   │   ├── telegram.ts
│   │   │   └── news-api.ts
│   │   ├── queue/
│   │   │   ├── index.ts
│   │   │   └── schedulers.ts
│   │   └── utils/
│   │       ├── logger.ts
│   │       └── helpers.ts
│   ├── workers/
│   │   ├── content-worker.ts
│   │   ├── social-listening-worker.ts
│   │   ├── email-worker.ts
│   │   └── research-worker.ts
│   └── jobs/
│       └── scheduled-tasks.ts
└── scripts/
    ├── setup-db.ts
    ├── seed-data.ts
    └── test-agents.ts
```

## 4. Data Model
Use Supabase with SQL defined via migration script (`scripts/setup-db.ts`) that executes the PRD SQL. Tables:
- agents_memory: semantic memory store with embeddings (1536 dims)
- content_calendar: content pipeline with statuses and Late.dev IDs
- campaigns: campaign lifecycle and budgets
- influencers: influencer CRM and pipeline stages
- social_listening_reports: daily mention/sentiment reports
- competitor_intelligence: tracked competitor updates
- email_log: campaign/outreach email events
- approval_queue: human approvals with Slack metadata

Indexes per PRD; ensure ivfflat index created after vectors populated and `SET ivfflat.probes` tuned if needed.

Repositories (lib/database/repositories/*) expose typed methods:
- content-calendar: create, update, getById, findByStatus({ status, platform, range })
- campaigns: create, update, listActive()
- influencers: create, update, getById, findByHandle(), search(criteria)
- email-log: create, markDelivered/opened/clicked
- memory: upsertMemory, queryByEmbedding, getByKey

## 5. Integrations
- Late.dev: REST wrapper as PRD; methods publishPost, getAccounts
- Fal.ai: REST wrapper to Flux; generateImage returns URL + seed
- Apify: Tweet/Google scrapers; run actor, poll `waitForFinish`, fetch dataset items
- Resend: official SDK; sendEmail(to[], subject, html, text?, scheduledAt?)
- Slack: @slack/web-api; sendMessage and sendApprovalRequest returning message ts
- Telegram: node-telegram-bot-api; sendMessage/sendPhoto to channel
- News API: thin wrapper `news-api.ts` for research agent

All integration modules must:
- accept config from env
- throw rich errors with provider status and safe context
- avoid logging secrets; only log provider name and status code

## 6. Agents
- BaseAgent: common interface `process(input)`, tool registry, telemetry hooks
- Master CMO: strategic planner; delegates via tool functions defined in PRD
- Manager Agents: Content, Outreach, Research, Operations. Each exposes process/delegate methods that call worker agents or tools
- Worker Agents: Poster (Late.dev), Creatives (Fal.ai), Social Listening (Apify), Email (Resend), Influencer, PR, Community (Telegram)
- Prompts: embed PRD prompts as constants per agent file; inject runtime variables (handles, account IDs)

Memory:
- memory-tools.ts exposes `storeMemory`, `queryMemory` backed by agents_memory with optional embeddings
- use pgvector similarity on `content` embeddings when `queryMemory` is called

## 7. Workflows
- content-publishing: given brief/platforms/type/image flag, orchestrate CMO → Content Manager → Creatives (optional) → Poster; write calendar; request approval or publish
- social-listening: scrape brand and competitor mentions, analyze sentiment via Social Listening Agent, store report, post Slack summary, send alerts
- influencer-outreach: find or fetch influencer, research, draft outreach, create approval or send, update status, log email
- email-campaigns: draft and send to segment via Resend, log, monitor basic events (polling/webhook placeholder)

## 8. Queue & Scheduling
- BullMQ queues: content, social-listening, email, research (lib/queue/index.ts)
- QueueSchedulers for delayed jobs
- Workers: one per queue, concurrency 5 (configurable); implement handlers mapping job.name to workflow invocations
- Cron (jobs/scheduled-tasks.ts):
  - 08:00 IST: social listening daily report
  - Monday 09:00 IST: weekly competitor analysis
  - Every 5 min: process scheduled content
  - 18:00 IST: daily email digest

Retry/backoff policy:
- default attempts: 3, backoff: exponential starting at 5s, max 2m
- on final failure: Slack alert with job name and payload hash

## 9. API Surface
- GET /health → 200, { status, version }
- POST /slack/interactions → verifies signing secret, parses actions, delegates to approval handler
- POST /content/create → enqueue content creation with brief/platforms/contentType/includeImage/scheduledFor/autoApprove
- POST /content/approval/:id → internal webhook (optional) to re-check approval and publish
- POST /webhooks/resend → placeholder for future email event ingestion

Security:
- Require a shared bearer token for internal POST routes (except Slack webhook which uses signing secret)
- Validate payloads with zod; enforce platform enums

## 10. Approval Flow
- db.approvalQueue.create() on sensitive actions
- Slack sendApprovalRequest() posts with Approve/Reject buttons (action_ids encode approvalId)
- api/slack/interactions.ts parses action, calls lib/approval.handleApproval(approvalId, approved, approvedBy)
- handleApproval executes: content publish, outreach email, or campaign send; updates related tables; posts confirmation

## 11. Configuration & Env
Required variables (see .env.example per PRD). Load via dotenv in dev. Never log secrets. Validate at startup with a small env schema; fail fast if missing critical keys.

## 12. Observability
- lib/utils/logger.ts exposes structured log() with levels debug/info/warn/error
- Include requestId/jobId, queue, worker, provider, statusCode in logs
- Slack alerts on:
  - queue fatal failure
  - approval errors
  - integration non-2xx with no retry remaining

## 13. Delivery Phases (Milestones)
- Phase 1: Foundation
  - Bootstrap project, lint/ts, basic API, Slack messaging smoke test, Supabase connectivity
- Phase 2: Core Integrations
  - Late.dev, Fal.ai, Apify, Resend, Telegram wrappers with small smoke tests
- Phase 3: Worker Agents
  - Poster, Creatives, Social Listening, Email agents using wrappers
- Phase 4: Manager Agents
  - Content, Outreach, Research, Operations coordination
- Phase 5: Orchestration
  - Master CMO, approval system, memory, queues
- Phase 6: Automation
  - Cron jobs, scheduled publishing processor, error/retry paths
- Phase 7: Testing & Hardening
  - E2E flow tests (happy paths), prompt refinements, cost/rate guardrails

Each phase ends with a deployable artifact and CLI/API smoke commands.

## 14. Verification Approach
- Lint: npm run lint
- Typecheck: npm run typecheck
- Tests: npm test (vitest)
- Manual checks:
  - GET /health returns 200 JSON
  - Slack test message to updates channel
  - Late.dev accounts list returns attached accounts
  - Fal.ai generates image URL
  - Apify returns dataset items for a small query
  - Resend sends to a test alias (in sandbox)
- E2E (staging):
  - Trigger content-publishing workflow with autoApprove=false → Slack approval → Approve → content published and calendar updated
  - Run social-listening cron job manually → report row + Slack summary
  - Run influencer-outreach with autoSend=false → approval → email sent, influencer updated, email_log written

## 15. Risk & Mitigation Notes (Engineering)
- Provider rate limits: exponential backoff + jitter; capture Retry-After where available
- Idempotency: include deterministic de-dupe keys for publish jobs (content hash + scheduledFor)
- Secrets hygiene: never print tokens; scrub payloads in error paths
- Regional constraints: vocabulary guardrails centralized in Poster/Content prompts and validators
