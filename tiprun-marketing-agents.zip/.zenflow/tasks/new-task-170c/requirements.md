# TipRun Autonomous Marketing System — Product Requirements Document (PRD)

Last updated: 2026-01-28

## 1. Executive Summary
Build an autonomous multi-agent marketing system for TipRun (IPL 2026 launch). Ten+ AI agents collaborate to plan campaigns, produce content, listen on social channels, run outreach, and coordinate approvals with minimal human intervention. The system integrates with Supabase (data + memory), BullMQ (orchestration), Redis, Late.dev (social posting), Fal.ai (images), Apify (scraping), Resend (email), Slack (approvals/alerts), and Telegram (community).

Primary outcomes:
- Consistently publish, monitor, and optimize marketing content across Twitter, Instagram, and Telegram.
- Run daily social listening and weekly competitor intelligence with actionable alerts.
- Execute influencer and email outreach with human-in-the-loop approvals.

## 2. Goals and Non-Goals
### Goals
- Reduce manual effort for daily social operations and reporting.
- Provide safe defaults with guardrails: approvals, schedules, and platform-specific rules.
- Centralize marketing data for analysis and iteration (content, performance, outreach, research).
- Enable scalable workflows via queues, retries, and modular agents.

### Non-Goals
- No on-platform trading functionality; this is strictly marketing ops.
- No paid ads buying or attribution setup in MVP.
- No fully autonomous spend approvals >$500 without human review.

## 3. Target Users
- Marketing Lead/CMO: Oversees strategy, approves sensitive items.
- Content Manager: Directs content calendar and assets.
- Outreach Manager: Influencer/PR/email pipeline.
- Operations: Scheduling, notifications, reporting.
- Community Manager: Telegram announcements & engagement.

## 4. Scope
### In Scope (MVP through Phase 2)
- Supabase schema for content calendar, memory, approvals, email logs, social listening, influencer DB.
- Slack notifications and approval workflow for content and outreach.
- Late.dev publishing for Twitter, Instagram, Telegram (draft/schedule/publish).
- Fal.ai image generation with brand guidelines.
- Apify scraping for Twitter/Google results used by research/social listening.
- Resend for campaign emails; Gmail for personalized outreach.
- Telegram bot for announcements.
- Basic API server with health check and Slack interaction handler.

### Future Scope (Phases 3–6)
- Manager and worker agents with delegation chains.
- Daily/weekly automated research pipelines.
- Expanded content types (threads, reels, stories) and multi-platform tailoring.
- Job scheduling, retries, rate limiting, and observability improvements.

### Out of Scope
- YouTube channel automation at launch (placeholder only).
- In-depth BI dashboarding beyond operational metrics.

## 5. Functional Requirements
### 5.1 Agent Orchestration
- Master CMO Agent delegates to manager agents (Campaign, Content, Outreach, Research, Operations) with defined prompts and tools.
- Worker agents (Poster, Creatives, Social Listening, Influencer, Email, PR, Community) perform atomic tasks.
- All agents follow brand voice and content rules (no gambling terms; use trade/predict/market vocabulary).

Acceptance:
- Given a content brief, the system produces a platform-appropriate draft, optional image, calendar entry, and triggers approval or schedules publish per rules.

### 5.2 Content Creation & Publishing
- Draft posts with platform-specific constraints and CTAs.
- Optionally request image; attach and schedule via Late.dev.
- Persist to `content_calendar` with statuses: draft, pending_approval, scheduled, published, failed.

Acceptance:
- Able to create a scheduled post with image for Twitter within 1 minute end-to-end in staging.
- Slack approval flow changes status and executes publish, then records Late.dev post ID.

### 5.3 Social Listening & Trends
- Daily scrape brand/competitor mentions and compute sentiment summary with top mentions and alerts.
- Save daily report; send Slack summary and immediate alerts for triggers.

Acceptance:
- Daily job produces a report row for the date with sentiment counts and summary message in Slack.

### 5.4 Influencer Outreach
- Maintain influencer records with tiers, niches, engagement, status stages.
- Draft personalized outreach and request approval; upon approval, send via Gmail or Resend (as applicable) and log to `email_log`.

Acceptance:
- Approving an outreach request updates influencer status to contacted and logs an email entry.

### 5.5 Email Campaigns
- Create campaign emails to segments (waitlist, active, lapsed, influencers) with A/B subject optional.
- Send via Resend with scheduling and log to `email_log` with delivery/open/click updates when available.

Acceptance:
- A campaign to a small test segment sends successfully and is logged.

### 5.6 Approvals & Human-in-the-Loop
- Any sensitive content, new campaigns, or outreach requires Slack approval.
- Approvals include title, details, requester, and action buttons; handler executes upon approve.

Acceptance:
- Approving content publishes via Late.dev, updates calendar, and posts confirmation to Slack.

### 5.7 Scheduling & Queues
- BullMQ queues for content, social-listening, email, research; cron schedules daily/weekly jobs.
- Retries for transient failures with backoff; dead-letter logging to Slack.

Acceptance:
- Missed run recovers on next tick; failed job retries up to N with alert on final failure.

## 6. Data Requirements
Key entities and intent (detailed SQL maintained in implementation):
- agents_memory: agent memories, embeddings for semantic search.
- content_calendar: planned/published posts and performance fields.
- campaigns: campaign objectives, budgets, metrics.
- influencers: pipeline and contact details.
- social_listening_reports: daily mention/sentiment summaries and alerts.
- competitor_intelligence: updates and suggested responses.
- email_log: campaign/outreach email events.
- approval_queue: pending/approved/rejected actions with Slack metadata.

Constraints:
- Use Supabase pgvector for embeddings; indexes for high-volume queries (status/date/platform).

## 7. Integrations & Limits
- Late.dev: publish posts, fetch accounts; handle rate limits and non-200 responses.
- Fal.ai: Flux model with safety checker enabled; store public asset URL.
- Apify: Tweet/Google scrapers; wait for run completion and fetch dataset items.
- Resend: campaign sends; observe free limits; schedule supported.
- Slack: approvals and alerts; store message TS where needed.
- Telegram: channel posts and photos for announcements.
- Redis/BullMQ: queues + schedulers; IST-aware cron.

## 8. Non-Functional Requirements
- Reliability: Retries with exponential backoff; idempotent publish where possible.
- Security: Do not log secrets; environment variables required for all providers.
- Compliance: Avoid gambling terminology; adhere to platform ToS and Indian regulatory sensitivities.
- Observability: Structured logs; Slack alerts on failures and anomalies; minimal PII in logs.
- Performance: Typical workflow latency under 60s for draft+schedule; scraping jobs can run async.
- Cost: Keep monthly API spend within projected ranges; prefer Haiku/mini models for workers.
- Timezone: Default Asia/Kolkata; all timestamps ISO8601.

## 9. Assumptions
- Social accounts exist and are connected in Late.dev with valid account IDs.
- Supabase project provisioned with pgvector; service key available server-side only.
- Redis instance reachable by workers; hosting supports persistent background processes.
- Slack bot installed with channel IDs configured; signing secret available for interactions.
- All API keys provided via environment.

## 10. Risks and Mitigations
- Misposting/brand risk: Mandatory approvals for non-template content; platform-specific validators.
- API rate limits/outages: Backoff + circuit breaker; graceful degradation and Slack alerts.
- Hallucination/brand drift: Strong prompts, style rules, and review gates; memory for decisions.
- Privacy/PII: Limit stored personal data; encrypt sensitive contact info where required.
- Regulatory perception: Strict vocabulary rules; avoid gambling terms.

## 11. Success Metrics
- Content publishing reliability: >99% of scheduled posts succeed or alert within 5 minutes.
- Social listening cadence: 7/7 daily reports delivered weekly.
- Outreach throughput: ≥10 approved outreach emails/week during active campaigns.
- Approval latency: Median < 2 hours during business hours.
- Cost efficiency: Stay within monthly budget bands.

## 12. Rollout & Phasing
- Phase 1–2 (Foundation/Core Integrations): DB, env, API, Slack, Late.dev, Fal.ai, Apify, Resend, Telegram.
- Phase 3–4 (Worker/Manager Agents): Poster/Creatives/Social Listening/Email; Content/Outreach/Research/Operations managers.
- Phase 5–6 (Orchestration/Automation): Master CMO, approvals, memory, queues, cron automation.
- Phase 7–8 (Testing/Refinement): E2E tests, prompt tuning, performance, documentation.

## 13. Open Questions (Need Clarification)
1. Final UTM base domain and campaign naming convention? (e.g., tiprun.io)
2. Media asset storage preference for generated images (Supabase storage/S3) and CDN policy?
3. Minimum approval rules for “auto-publish” templates by platform?
4. Exact influencer niches priority and budget caps per tier for IPL 2026 pre-launch?
5. Gmail vs. Resend for semi-personalized outreach at small scale—preferred channel?
6. Slack channel naming/IDs confirmed and any additional routing rules?
7. Any regional language content requirements beyond English/Hinglish?
8. Legal review requirements for certain content types or partnerships?
9. Preferred hosting (Railway vs Render) and deployment environments (staging/prod)?
10. News API provider choice and acceptable sources list if different from baseline?

## 14. Acceptance Criteria (MVP Readiness)
- Health endpoint returns 200 and version info.
- Create scheduled Twitter post with optional image via one function call; entry recorded in `content_calendar`.
- Approval flow from Slack executes publishing and updates calendar + Slack confirmation.
- Daily social listening job writes a report and posts summary in Slack; alerts for defined triggers.
- Influencer outreach approval sends email and updates influencer status + `email_log`.
- All secrets loaded from environment; no secrets in logs; failures alert to Slack.
