# Full SDD workflow

## Configuration
- **Artifacts Path**: {@artifacts_path} → `.zenflow/tasks/{task_id}`

---

## Workflow Steps

### [x] Step: Requirements
<!-- chat-id: dcce52df-523a-4a85-8ec8-8687a83f22b2 -->

Create a Product Requirements Document (PRD) based on the feature description.

1. Review existing codebase to understand current architecture and patterns
2. Analyze the feature definition and identify unclear aspects
3. Ask the user for clarifications on aspects that significantly impact scope or user experience
4. Make reasonable decisions for minor details based on context and conventions
5. If user can't clarify, make a decision, state the assumption, and continue

Save the PRD to `{@artifacts_path}/requirements.md`.

### [x] Step: Technical Specification
<!-- chat-id: 41c11dd1-2913-4a03-b4db-f264d8984214 -->

Create a technical specification based on the PRD in `{@artifacts_path}/requirements.md`.

1. Review existing codebase architecture and identify reusable components
2. Define the implementation approach

Save to `{@artifacts_path}/spec.md` with:
- Technical context (language, dependencies)
- Implementation approach referencing existing code patterns
- Source code structure changes
- Data model / API / interface changes
- Delivery phases (incremental, testable milestones)
- Verification approach using project lint/test commands

### [x] Step: Planning
<!-- chat-id: 111f237f-f4a1-4e37-b4f3-5864954c41ee -->

Create a detailed implementation plan based on `{@artifacts_path}/spec.md`.

1. Break down the work into concrete tasks
2. Each task should reference relevant contracts and include verification steps
3. Replace the Implementation step below with the planned tasks

Rule of thumb for step size: each step should represent a coherent unit of work (e.g., implement a component, add an API endpoint, write tests for a module). Avoid steps that are too granular (single function) or too broad (entire feature).

If the feature is trivial and doesn't warrant full specification, update this workflow to remove unnecessary steps and explain the reasoning to the user.

Save to `{@artifacts_path}/plan.md`.

### [x] Step: Project Bootstrap
<!-- chat-id: 962bdc49-747c-4994-b224-f437d5c75236 -->
- Initialize Node.js 20+ TypeScript project skeleton and scripts: build, dev, start, lint, typecheck, test
- Create `.gitignore` with node_modules/, dist/, build/, .cache/, coverage/, *.log
- Add `.env.example` with all required keys from spec; add dotenv for local dev
- Contracts: `package.json`, `tsconfig.json`, `.env.example`
- Verification: run `npm run typecheck` and `npm run lint` with no errors

### [x] Step: Environment Validation
<!-- chat-id: 3a674c6a-3380-4296-b7cc-760922606bea -->
- Implement env loader/validator to ensure required variables exist at startup
- Fail fast with clear messages; never print secret values
- Contracts: `src/lib/utils/helpers.ts` (env schema), usage in `src/index.ts`
- Verification: remove a key locally → process exits with actionable error

### [x] Step: Supabase Setup & Repositories
<!-- chat-id: 1af85f00-33ae-47a7-b736-06b679f15f47 -->
- Implement `scripts/setup-db.ts` applying SQL schema and indexes from spec
- Create Supabase client and typed repositories for entities
- Contracts: `src/lib/database/supabase-client.ts`, `src/lib/database/index.ts`, `src/lib/database/repositories/*`
- Verification: run setup script against dev DB; CRUD smoke for one repo via Vitest

### [x] Step: API Server & Health Route
<!-- chat-id: 9cbed6d7-9169-4a0c-a63d-50e20893fb75 -->
- Create Hono app with basic middleware and GET `/health` route
- Wire server bootstrap in `src/index.ts`
- Contracts: `src/api/index.ts`, `src/api/routes/health.ts`, `src/index.ts`
- Verification: server runs locally; GET `/health` returns 200 with status/version

### [x] Step: Slack Integration
<!-- chat-id: c8e8571e-c6ba-453a-a4a9-ebc5df21b90d -->
- Implement Slack client helpers for `sendMessage` and `sendApprovalRequest`
- Add channels config via env; redact tokens in logs
- Contracts: `src/lib/integrations/slack.ts`
- Verification: send a test message to `updates` channel and capture `ts`

### [x] Step: Late.dev Integration
<!-- chat-id: 04188c3a-a6be-4100-abc3-5925fc6432e1 -->
- Implement REST wrapper for publishing and accounts list
- Handle non-2xx with rich errors; accept scheduled publish
- Contracts: `src/lib/integrations/late-dev.ts`
- Verification: list accounts (sandbox/mocked) and dry-run publish path in tests

### [x] Step: Fal.ai Integration
<!-- chat-id: f6da8614-c301-42f8-b114-9682c9befc8c -->
- Implement image generation wrapper to Flux with safety checker
- Return `imageUrl` and `seed`; parameterize size
- Contracts: `src/lib/integrations/fal-ai.ts`
- Verification: request generates a valid URL (mock in tests)

### [x] Step: Apify Integration
<!-- chat-id: 9c5f56a3-07e0-4b32-be07-cb881aa21705 -->
- Implement Tweet and Google Search scrapers; wait for run, fetch dataset items
- Contracts: `src/lib/integrations/apify.ts`
- Verification: small query returns items (mock actor responses in tests)

### [x] Step: Resend Integration
<!-- chat-id: c489b7dd-ce55-4e25-b0f5-a2688e26e46d -->
- Implement sendEmail wrapper with scheduling support
- Contracts: `src/lib/integrations/resend.ts`
- Verification: send to test alias (or mock) returns id; no secrets logged

### [x] Step: Telegram Integration
<!-- chat-id: 84878979-7cb3-4d3f-b4fc-a4b90b84f5a8 -->
- Implement channel message/photo helpers
- Contracts: `src/lib/integrations/telegram.ts`
- Verification: send to test channel (or mock) succeeds

### [x] Step: Database Wiring & Tests
<!-- chat-id: d0a1833b-72a4-473c-95ca-58c6e55f4759 -->
- Export `db` object aggregating repositories with consistent method names
- Add minimal Vitest setup and repo unit tests with test DB or mocks
- Contracts: `src/lib/database/index.ts`, `tests/integrations/*`
- Verification: `npm test` runs repo tests green

### [x] Step: Base Agent & Poster Agent
<!-- chat-id: 366d4f93-633e-4dae-a124-ab9624e2a859 -->
- Create BaseAgent interface and telemetry hooks
- Implement PosterAgent with prompts and publish via Late.dev
- Contracts: `src/agents/base-agent.ts`, `src/agents/poster-agent.ts`
- Verification: unit test publish call builds correct payload; dry-run OK

### [x] Step: Creatives Agent
<!-- chat-id: c5c660e4-7d56-4821-89d5-2fe7d217ebb5 -->
- Implement prompts and `generateImage` flow; optional storage upload placeholder
- Contracts: `src/agents/creatives-agent.ts`
- Verification: returns image metadata and URL for given prompt (mock)

### [x] Step: Social Listening Agent
<!-- chat-id: 7970888b-6dd6-42bc-8563-a4244a570ecf -->
- Implement analyze to compute sentiment buckets, score, alerts from tweet samples
- Contracts: `src/agents/social-listening-agent.ts`
- Verification: fixture input yields deterministic report JSON

### [x] Step: Email Agent
<!-- chat-id: 57c64840-1c02-4395-b1d0-5bd9dc58ecd5 -->
- Implement campaign and outreach send paths; log to `email_log`
- Contracts: `src/agents/email-agent.ts`
- Verification: mocked send writes email_log via repo

### [x] Step: Content Manager Agent
<!-- chat-id: 16d1e288-06c3-4b52-833f-af0fc74b8c7a -->
- Implement delegation to Poster/Creatives/Social Listening; content calendar updates
- Contracts: `src/agents/content-manager.ts`
- Verification: given brief/platforms outputs content struct and calendar draft

### [x] Step: Influencer Agent & Outreach Manager
<!-- chat-id: efe2a3d0-f833-41dc-a3d3-83f257f7520a -->
- Implement influencer research/draft outreach; outreach manager orchestrates email/PR
- Contracts: `src/agents/influencer-agent.ts`, `src/agents/outreach-manager.ts`
- Verification: outreach draft JSON includes personalized angle; approval payload ready

### [x] Step: Research & Operations Agents
<!-- chat-id: e7ed0465-4b18-4f47-8b7a-c108b3b29c22 -->
- Implement research queries over Apify/News and summary; operations Slack messages
- Contracts: `src/agents/research-agent.ts`, `src/agents/operations-agent.ts`
- Verification: mocked sources produce recommendations; Slack summary format correct

### [x] Step: Core Workflows
<!-- chat-id: eec76d8c-eee6-4399-9dd1-b5564c069832 -->
- Implement content-publishing, social-listening, influencer-outreach, email-campaigns, research-reports
- Ensure db writes and Slack notifications per spec
- Contracts: `src/workflows/*.ts`
- Verification: call each workflow with fixtures; assert outputs and repo writes

### [x] Step: Approval System
<!-- chat-id: e593e758-21a7-425e-9ae2-d57f13ab3cec -->
- Implement approval creation, Slack interactions handler, and executor
- Update related tables on approve/reject
- Contracts: `src/lib/approval.ts`, `src/api/slack/interactions.ts`
- Verification: simulate approve for content → Late.dev publish invoked; calendar updated

### [x] Step: Queues & Workers
<!-- chat-id: d554c6e5-7fc4-4ede-ba23-358eeb199aa6 -->
- Create BullMQ queues and workers mapping job names to workflows
- Add retry/backoff defaults and failure alerts to Slack
- Contracts: `src/lib/queue/index.ts`, `src/workers/*`
- Verification: enqueue job processes with concurrency and reports completion

### [x] Step: Cron Schedules
<!-- chat-id: d6bce020-17e0-47d8-86e8-15ded2fa4d15 -->
- Configure IST cron for daily/weekly tasks and scheduled content checks
- Contracts: `src/jobs/scheduled-tasks.ts`, `src/lib/queue/schedulers.ts`
- Verification: cron enqueues expected jobs when triggered manually

### [x] Step: API Routes
<!-- chat-id: a7293876-0cf1-47f0-93db-e2e4019d9452 -->
- Implement POST `/content/create`, POST `/webhooks/resend`, POST `/slack/interactions`
- Secure with bearer token or signing secret; zod-validate payloads
- Contracts: `src/api/routes/content.ts`, `src/api/routes/webhooks.ts`, `src/api/index.ts`
- Verification: POST creates queue jobs, returns ids; Slack interaction path works

### [x] Step: Observability & Errors
<!-- chat-id: 2d181ddd-e0eb-47a8-bdad-80d452309201 -->
- Implement `logger.ts`; enrich integration errors; Slack alerts on final failures
- Contracts: `src/lib/utils/logger.ts`
- Verification: forced failure triggers alert; logs contain provider/status without secrets

### [x] Step: Testing & Tooling
<!-- chat-id: 2ae7e8cb-8c81-41e1-80f4-cfb6c4a8bd88 -->
- Add Vitest config and tests across integrations, agents, repos, approval, workflows
- Ensure eslint/prettier configuration; CI script placeholders
- Contracts: `tests/**`, `package.json` scripts
- Verification: `npm test`, `npm run lint`, `npm run typecheck` pass locally

### [x] Step: Deployment Prep
<!-- chat-id: f5ce80b1-a752-4b34-84fc-800eb8b57331 -->
- Add minimal Dockerfile or deployment config; ensure envs documented in `.env.example`
- Smoke checklist for staging: /health, Slack message, Late.dev accounts, Fal.ai mock
- Contracts: `Dockerfile` (optional), deployment config, `.env.example`
- Verification: staging boots; healthcheck OK; basic smoke flows succeed
